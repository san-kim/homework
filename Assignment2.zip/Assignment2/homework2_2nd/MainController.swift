//
//  ViewController.swift
//  homework2_2nd
//
//  Created by Kiwook Kim on 6/30/16.
//  Copyright © 2016 sankim. All rights reserved.
//

import UIKit

class MainController: UIViewController
{

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

